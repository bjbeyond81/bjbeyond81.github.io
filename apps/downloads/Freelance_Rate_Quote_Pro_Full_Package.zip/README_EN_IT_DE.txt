========================================================================
Freelance Rate & Quote Pro — Web App (BJ-APP-FREELANCE)
BJ Beyond • https://bjbeyond.studio
========================================================================

🇬🇧 ENGLISH — WHAT'S INCLUDED IN THIS PACKAGE:
1. Freelance_Rate_Quote_Pro_App.html
   -> Standalone Offline Application! Double-click this file to open the
      full application directly in any browser (Chrome, Safari, Edge, Firefox)
      on Mac, Windows, Linux, iPad, or Android — even with ZERO internet!
2. Freelance_Rate_Pro_Access.pdf
   -> Quick-Start & Installation Guide with QR Code and direct links.
3. pwa/ folder
   -> Complete Progressive Web App files (index.html, manifest.json, sw.js, icons).
   -> Live Online PWA URL: https://bjbeyond81.github.io/apps/freelance-rate-pro/

------------------------------------------------------------------------
🇮🇹 ITALIANO — COSA CONTIENE QUESTO PACCHETTO:
1. Freelance_Rate_Quote_Pro_App.html
   -> Applicazione Standalone Offline! Fai doppio clic su questo file per
      aprire subito l'applicazione completa su qualsiasi computer (Mac/Windows)
      o tablet, anche completamente SENZA connessione internet.
2. Freelance_Rate_Pro_Access.pdf
   -> Guida Rapida in PDF con QR Code e istruzioni per iPhone, Android e PC.
3. Cartella pwa/
   -> Tutti i file sorgente della Progressive Web App (index.html, manifest, icone).
   -> Link Diretto Web App Online: https://bjbeyond81.github.io/apps/freelance-rate-pro/

------------------------------------------------------------------------
🇩🇪 DEUTSCH — INHALT DIESES PAKETS:
1. Freelance_Rate_Quote_Pro_App.html
   -> Eigenständige Offline-Anwendung! Doppelklicken Sie auf diese Datei, um
      die komplette App direkt in jedem Browser ohne Internet zu starten.
2. Freelance_Rate_Pro_Access.pdf
   -> Schnellstart-Anleitung als PDF mit QR-Code.
3. Ordner pwa/
   -> Komplette Progressive Web App Dateien.
   -> Direkter Online-Link: https://bjbeyond81.github.io/apps/freelance-rate-pro/
========================================================================
